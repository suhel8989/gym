"use client"

import { Button } from "@/components/ui/button"

import { useAuth } from "@/components/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, CreditCard, TrendingUp, Bell } from "lucide-react"

// Mock data for dashboard
const mockStats = {
  admin: {
    totalMembers: 42,
    activeMembers: 38,
    totalPayments: 3250,
    pendingPayments: 450,
    notifications: 5,
    unreadNotifications: 2,
  },
  member: {
    notifications: 3,
    unreadNotifications: 1,
  },
}

export default function DashboardPage() {
  const { user } = useAuth()

  // Use mock stats based on user role
  const stats = user?.role === "admin" ? mockStats.admin : { ...mockStats.member }

  // Render different dashboards based on user role
  const renderAdminDashboard = () => (
    <>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Members</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalMembers}</div>
            <p className="text-xs text-muted-foreground">{stats.activeMembers} active members</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Payments</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats.totalPayments.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">${stats.pendingPayments.toLocaleString()} pending</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Growth Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">+12.5%</div>
            <p className="text-xs text-muted-foreground">+2.5% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Notifications</CardTitle>
            <Bell className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.notifications}</div>
            <p className="text-xs text-muted-foreground">{stats.unreadNotifications} unread</p>
          </CardContent>
        </Card>
      </div>
      <Tabs defaultValue="overview" className="mt-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Overview of recent gym activities and operations.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">New Members</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">+5</div>
                      <p className="text-xs text-muted-foreground">this week</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Payments Received</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">$1,250</div>
                      <p className="text-xs text-muted-foreground">this week</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Supplement Sales</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">$450</div>
                      <p className="text-xs text-muted-foreground">this week</p>
                    </CardContent>
                  </Card>
                </div>

                <div className="mt-6">
                  <h3 className="font-medium mb-4">Recent Member Activity</h3>
                  <div className="rounded-lg border overflow-hidden">
                    <div className="grid grid-cols-3 gap-4 p-4 bg-gray-50 dark:bg-gray-800 font-medium">
                      <div>Member</div>
                      <div>Activity</div>
                      <div>Time</div>
                    </div>
                    <div className="divide-y">
                      <div className="grid grid-cols-3 gap-4 p-4">
                        <div className="flex items-center gap-2">
                          <img
                            src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
                            alt="Member"
                            className="h-8 w-8 rounded-full object-cover"
                          />
                          <span>John Doe</span>
                        </div>
                        <div className="flex items-center">Check-in</div>
                        <div className="flex items-center text-gray-500">10 minutes ago</div>
                      </div>
                      <div className="grid grid-cols-3 gap-4 p-4">
                        <div className="flex items-center gap-2">
                          <img
                            src="https://images.unsplash.com/photo-1548690312-e3b507d8c110?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80"
                            alt="Member"
                            className="h-8 w-8 rounded-full object-cover"
                          />
                          <span>Sarah Johnson</span>
                        </div>
                        <div className="flex items-center">Payment</div>
                        <div className="flex items-center text-gray-500">25 minutes ago</div>
                      </div>
                      <div className="grid grid-cols-3 gap-4 p-4">
                        <div className="flex items-center gap-2">
                          <img
                            src="https://images.unsplash.com/photo-1517838277536-f5f99be501cd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
                            alt="Member"
                            className="h-8 w-8 rounded-full object-cover"
                          />
                          <span>Michael Rodriguez</span>
                        </div>
                        <div className="flex items-center">Class Registration</div>
                        <div className="flex items-center text-gray-500">1 hour ago</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="analytics" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Analytics</CardTitle>
              <CardDescription>Detailed analytics about gym performance and member activities.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                <div>
                  <h3 className="font-medium mb-4">Membership Growth</h3>
                  <div className="h-[200px] bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                    <p className="text-muted-foreground">Membership growth chart will be displayed here</p>
                  </div>
                </div>
                <div>
                  <h3 className="font-medium mb-4">Revenue Breakdown</h3>
                  <div className="h-[200px] bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                    <p className="text-muted-foreground">Revenue breakdown chart will be displayed here</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Reports</CardTitle>
              <CardDescription>Generate and view reports about gym operations.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Monthly Revenue Report</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-500 mb-4">Summary of all revenue streams for the current month</p>
                      <Button variant="outline" className="w-full">
                        Generate Report
                      </Button>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Member Activity Report</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-500 mb-4">Detailed breakdown of member attendance and activity</p>
                      <Button variant="outline" className="w-full">
                        Generate Report
                      </Button>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Class Attendance Report</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-500 mb-4">Analysis of class attendance and popularity</p>
                      <Button variant="outline" className="w-full">
                        Generate Report
                      </Button>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Financial Summary</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-500 mb-4">
                        Complete financial overview with expenses and revenue
                      </p>
                      <Button variant="outline" className="w-full">
                        Generate Report
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </>
  )

  const renderMemberDashboard = () => (
    <>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Membership Status</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Active</div>
            <p className="text-xs text-muted-foreground">Valid until June 30, 2025</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Next Payment</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$75.00</div>
            <p className="text-xs text-muted-foreground">Due on June 1, 2025</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Notifications</CardTitle>
            <Bell className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.notifications}</div>
            <p className="text-xs text-muted-foreground">{stats.unreadNotifications} unread</p>
          </CardContent>
        </Card>
      </div>
      <Tabs defaultValue="overview" className="mt-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="diet">Diet Plan</TabsTrigger>
          <TabsTrigger value="payments">Payment History</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Member Information</CardTitle>
              <CardDescription>Your membership details and upcoming events.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <h3 className="font-medium mb-2">Membership Package</h3>
                    <div className="rounded-lg border p-3">
                      <div className="font-medium">Premium Membership</div>
                      <div className="text-sm text-muted-foreground">
                        Full access to gym facilities, classes, and personal training sessions
                      </div>
                    </div>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Upcoming Classes</h3>
                    <div className="rounded-lg border p-3">
                      <div className="font-medium">Yoga Class</div>
                      <div className="text-sm text-muted-foreground">Thursday, May 23 - 6:00 PM</div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Recent Activity</h3>
                  <div className="rounded-lg border overflow-hidden">
                    <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 dark:bg-gray-800 font-medium">
                      <div>Activity</div>
                      <div>Date & Time</div>
                    </div>
                    <div className="divide-y">
                      <div className="grid grid-cols-2 gap-4 p-4">
                        <div className="flex items-center">Gym Check-in</div>
                        <div className="flex items-center text-gray-500">Today, 9:30 AM</div>
                      </div>
                      <div className="grid grid-cols-2 gap-4 p-4">
                        <div className="flex items-center">Yoga Class</div>
                        <div className="flex items-center text-gray-500">Yesterday, 6:00 PM</div>
                      </div>
                      <div className="grid grid-cols-2 gap-4 p-4">
                        <div className="flex items-center">Personal Training</div>
                        <div className="flex items-center text-gray-500">May 20, 2025, 10:00 AM</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <h3 className="font-medium mb-2">Fitness Progress</h3>
                    <div className="rounded-lg border p-4">
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Weight Goal</span>
                        <span className="text-sm text-primary">75%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-primary h-2.5 rounded-full" style={{ width: "75%" }}></div>
                      </div>

                      <div className="flex justify-between mb-2 mt-4">
                        <span className="text-sm font-medium">Strength Goal</span>
                        <span className="text-sm text-primary">60%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-primary h-2.5 rounded-full" style={{ width: "60%" }}></div>
                      </div>

                      <div className="flex justify-between mb-2 mt-4">
                        <span className="text-sm font-medium">Cardio Goal</span>
                        <span className="text-sm text-primary">85%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                        <div className="bg-primary h-2.5 rounded-full" style={{ width: "85%" }}></div>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Personal Trainer</h3>
                    <div className="rounded-lg border p-4">
                      <div className="flex items-center gap-3 mb-3">
                        <img
                          src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
                          alt="Trainer"
                          className="h-12 w-12 rounded-full object-cover"
                        />
                        <div>
                          <div className="font-medium">Alex Thompson</div>
                          <div className="text-sm text-gray-500">Certified Personal Trainer</div>
                        </div>
                      </div>
                      <div className="text-sm text-gray-500 mb-3">Next session: Friday, May 24 - 10:00 AM</div>
                      <Button variant="outline" size="sm" className="w-full">
                        Contact Trainer
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="diet" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Your Diet Plan</CardTitle>
              <CardDescription>Personalized nutrition plan for your fitness goals.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid gap-4 md:grid-cols-3">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Breakfast</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex items-center gap-2">
                        <img
                          src="https://images.unsplash.com/photo-1494390248081-4e521a5940db?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1406&q=80"
                          alt="Breakfast"
                          className="h-12 w-12 rounded object-cover"
                        />
                        <div>
                          <div className="font-medium">Protein Oatmeal</div>
                          <div className="text-xs text-gray-500">350 calories</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <img
                          src="https://images.unsplash.com/photo-1615485290382-441e4d049cb5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
                          alt="Breakfast"
                          className="h-12 w-12 rounded object-cover"
                        />
                        <div>
                          <div className="font-medium">Greek Yogurt</div>
                          <div className="text-xs text-gray-500">150 calories</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Lunch</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex items-center gap-2">
                        <img
                          src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1160&q=80"
                          alt="Lunch"
                          className="h-12 w-12 rounded object-cover"
                        />
                        <div>
                          <div className="font-medium">Chicken Salad</div>
                          <div className="text-xs text-gray-500">450 calories</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <img
                          src="https://images.unsplash.com/photo-1610970881699-44a5587cabec?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1374&q=80"
                          alt="Lunch"
                          className="h-12 w-12 rounded object-cover"
                        />
                        <div>
                          <div className="font-medium">Sweet Potato</div>
                          <div className="text-xs text-gray-500">200 calories</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Dinner</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex items-center gap-2">
                        <img
                          src="https://images.unsplash.com/photo-1467003909585-2f8a72700288?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1374&q=80"
                          alt="Dinner"
                          className="h-12 w-12 rounded object-cover"
                        />
                        <div>
                          <div className="font-medium">Salmon</div>
                          <div className="text-xs text-gray-500">400 calories</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <img
                          src="https://images.unsplash.com/photo-1540420773420-3366772f4999?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1384&q=80"
                          alt="Dinner"
                          className="h-12 w-12 rounded object-cover"
                        />
                        <div>
                          <div className="font-medium">Roasted Vegetables</div>
                          <div className="text-xs text-gray-500">250 calories</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Nutritional Goals</h3>
                  <div className="rounded-lg border p-4">
                    <div className="grid gap-4 md:grid-cols-3">
                      <div>
                        <div className="text-sm text-gray-500">Daily Calories</div>
                        <div className="text-xl font-bold">2,200 / 2,500</div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700 mt-2">
                          <div className="bg-primary h-2.5 rounded-full" style={{ width: "88%" }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-500">Protein (g)</div>
                        <div className="text-xl font-bold">145 / 180</div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700 mt-2">
                          <div className="bg-primary h-2.5 rounded-full" style={{ width: "80%" }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-500">Water (L)</div>
                        <div className="text-xl font-bold">2.5 / 3.0</div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700 mt-2">
                          <div className="bg-primary h-2.5 rounded-full" style={{ width: "83%" }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Supplements</h3>
                  <div className="rounded-lg border overflow-hidden">
                    <div className="grid grid-cols-4 gap-4 p-4 bg-gray-50 dark:bg-gray-800 font-medium">
                      <div>Supplement</div>
                      <div>Dosage</div>
                      <div>Timing</div>
                      <div>Purpose</div>
                    </div>
                    <div className="divide-y">
                      <div className="grid grid-cols-4 gap-4 p-4">
                        <div className="flex items-center">Protein Powder</div>
                        <div className="flex items-center">25g</div>
                        <div className="flex items-center">Post-workout</div>
                        <div className="flex items-center text-gray-500">Muscle recovery</div>
                      </div>
                      <div className="grid grid-cols-4 gap-4 p-4">
                        <div className="flex items-center">Creatine</div>
                        <div className="flex items-center">5g</div>
                        <div className="flex items-center">Daily</div>
                        <div className="flex items-center text-gray-500">Strength & power</div>
                      </div>
                      <div className="grid grid-cols-4 gap-4 p-4">
                        <div className="flex items-center">Multivitamin</div>
                        <div className="flex items-center">1 tablet</div>
                        <div className="flex items-center">Morning</div>
                        <div className="flex items-center text-gray-500">General health</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="payments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Payment History</CardTitle>
              <CardDescription>View your past payments and receipts.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg border overflow-hidden">
                <div className="grid grid-cols-5 gap-4 p-4 bg-gray-50 dark:bg-gray-800 font-medium">
                  <div>Date</div>
                  <div>Description</div>
                  <div>Amount</div>
                  <div>Status</div>
                  <div>Receipt</div>
                </div>
                <div className="divide-y">
                  <div className="grid grid-cols-5 gap-4 p-4">
                    <div className="flex items-center">May 1, 2025</div>
                    <div className="flex items-center">Monthly Membership</div>
                    <div className="flex items-center">$75.00</div>
                    <div className="flex items-center">
                      <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800 dark:bg-green-800/30 dark:text-green-500">
                        Paid
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Button variant="ghost" size="sm">
                        View
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-5 gap-4 p-4">
                    <div className="flex items-center">Apr 1, 2025</div>
                    <div className="flex items-center">Monthly Membership</div>
                    <div className="flex items-center">$75.00</div>
                    <div className="flex items-center">
                      <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800 dark:bg-green-800/30 dark:text-green-500">
                        Paid
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Button variant="ghost" size="sm">
                        View
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-5 gap-4 p-4">
                    <div className="flex items-center">Mar 1, 2025</div>
                    <div className="flex items-center">Monthly Membership</div>
                    <div className="flex items-center">$75.00</div>
                    <div className="flex items-center">
                      <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800 dark:bg-green-800/30 dark:text-green-500">
                        Paid
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Button variant="ghost" size="sm">
                        View
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-5 gap-4 p-4">
                    <div className="flex items-center">Feb 1, 2025</div>
                    <div className="flex items-center">Monthly Membership</div>
                    <div className="flex items-center">$75.00</div>
                    <div className="flex items-center">
                      <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800 dark:bg-green-800/30 dark:text-green-500">
                        Paid
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Button variant="ghost" size="sm">
                        View
                      </Button>
                    </div>
                  </div>
                  <div className="grid grid-cols-5 gap-4 p-4">
                    <div className="flex items-center">Jan 15, 2025</div>
                    <div className="flex items-center">Personal Training Session</div>
                    <div className="flex items-center">$50.00</div>
                    <div className="flex items-center">
                      <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800 dark:bg-green-800/30 dark:text-green-500">
                        Paid
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Button variant="ghost" size="sm">
                        View
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </>
  )

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground">Welcome back, {user?.displayName || "User"}!</p>
      </div>

      {user?.role === "admin" ? renderAdminDashboard() : renderMemberDashboard()}
    </div>
  )
}
