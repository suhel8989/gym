"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { MoreHorizontal, Search, Filter, Download, Receipt } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { logEvent } from "@/lib/firebase/analytics"

// Mock data for payments
const mockPayments = [
  {
    id: "pay_1",
    memberId: "mem_1",
    memberName: "John Doe",
    amount: 75.0,
    date: "2025-05-01",
    status: "paid",
    paymentMethod: "credit_card",
    description: "Monthly membership fee - May 2025",
  },
  {
    id: "pay_2",
    memberId: "mem_2",
    memberName: "Jane Smith",
    amount: 100.0,
    date: "2025-05-02",
    status: "paid",
    paymentMethod: "bank_transfer",
    description: "Premium membership fee - May 2025",
  },
  {
    id: "pay_3",
    memberId: "mem_3",
    memberName: "Robert Johnson",
    amount: 50.0,
    date: "2025-05-03",
    status: "pending",
    paymentMethod: "cash",
    description: "Basic membership fee - May 2025",
  },
  {
    id: "pay_4",
    memberId: "mem_4",
    memberName: "Emily Davis",
    amount: 120.0,
    date: "2025-05-04",
    status: "paid",
    paymentMethod: "credit_card",
    description: "VIP membership fee - May 2025",
  },
  {
    id: "pay_5",
    memberId: "mem_5",
    memberName: "Michael Wilson",
    amount: 75.0,
    date: "2025-05-05",
    status: "failed",
    paymentMethod: "credit_card",
    description: "Monthly membership fee - May 2025",
  },
]

export default function PaymentsPage() {
  const { user } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [payments, setPayments] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    // Load payments based on user role
    const loadPayments = async () => {
      setIsLoading(true)

      try {
        // In a real app, this would fetch from Firebase
        // For now, we'll use mock data
        setTimeout(() => {
          if (user?.role === "admin") {
            // Admin sees all payments
            setPayments(mockPayments)
          } else {
            // Member sees only their payments
            setPayments(mockPayments.filter((p) => p.memberId === user?.uid))
          }
          setIsLoading(false)
        }, 1000)

        logEvent("payments_page_viewed", { role: user?.role })
      } catch (error) {
        console.error("Error loading payments:", error)
        toast({
          title: "Error",
          description: "Failed to load payments.",
          variant: "destructive",
        })
        setIsLoading(false)
      }
    }

    if (user) {
      loadPayments()
    }
  }, [user, toast])

  const handleGenerateReceipt = (paymentId: string) => {
    // In a real app, this would generate a PDF receipt
    toast({
      title: "Receipt Generated",
      description: "The receipt has been generated and is ready for download.",
    })
    logEvent("receipt_generated", { paymentId })
  }

  const filteredPayments = payments.filter((payment) => {
    if (!searchQuery) return true

    const query = searchQuery.toLowerCase()
    return (
      payment.memberName?.toLowerCase().includes(query) ||
      payment.description?.toLowerCase().includes(query) ||
      payment.amount.toString().includes(query)
    )
  })

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "paid":
        return "success"
      case "pending":
        return "warning"
      case "failed":
        return "destructive"
      default:
        return "secondary"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Payments</h2>
          <p className="text-muted-foreground">
            {user?.role === "admin"
              ? "Manage all payments and generate receipts."
              : "View your payment history and receipts."}
          </p>
        </div>
        {user?.role === "admin" && (
          <Button onClick={() => router.push("/dashboard/payments/create")}>
            <Receipt className="mr-2 h-4 w-4" />
            Create Payment
          </Button>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Payments List</CardTitle>
          <CardDescription>
            {user?.role === "admin" ? "View and manage all payments." : "View your payment history."}
          </CardDescription>
          <div className="flex items-center gap-2 mt-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search payments..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
              <span className="sr-only">Filter</span>
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center h-40">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
            </div>
          ) : filteredPayments.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 space-y-3">
              <p className="text-muted-foreground">No payments found.</p>
              {user?.role === "admin" && (
                <Button variant="outline" onClick={() => router.push("/dashboard/payments/create")}>
                  <Receipt className="mr-2 h-4 w-4" />
                  Create Payment
                </Button>
              )}
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    {user?.role === "admin" && <TableHead>Member</TableHead>}
                    <TableHead>Description</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPayments.map((payment) => (
                    <TableRow key={payment.id}>
                      <TableCell>{new Date(payment.date).toLocaleDateString()}</TableCell>
                      {user?.role === "admin" && <TableCell>{payment.memberName}</TableCell>}
                      <TableCell>{payment.description}</TableCell>
                      <TableCell>${payment.amount.toFixed(2)}</TableCell>
                      <TableCell>
                        <Badge variant={getStatusBadgeVariant(payment.status) as any}>{payment.status}</Badge>
                      </TableCell>
                      <TableCell>{payment.paymentMethod.replace("_", " ")}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Actions</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => router.push(`/dashboard/payments/${payment.id}`)}>
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleGenerateReceipt(payment.id)}>
                              Generate Receipt
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Download className="mr-2 h-4 w-4" />
                              Download Receipt
                            </DropdownMenuItem>
                            {user?.role === "admin" && (
                              <DropdownMenuItem onClick={() => router.push(`/dashboard/payments/edit/${payment.id}`)}>
                                Edit Payment
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
