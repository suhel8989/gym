import Link from "next/link"

export function Footer() {
  return (
    <footer className="w-full border-t py-6 md:py-8 bg-gray-50 dark:bg-gray-900">
      <div className="container flex flex-col items-center justify-center gap-4 px-4 md:px-6 md:flex-row md:justify-between">
        <div className="flex items-center gap-2 font-bold">
          <span className="text-primary">GYM</span> Management System
        </div>
        <div className="flex gap-4 text-sm">
          <Link href="#" className="text-gray-500 hover:text-gray-900 dark:hover:text-gray-300">
            Terms
          </Link>
          <Link href="#" className="text-gray-500 hover:text-gray-900 dark:hover:text-gray-300">
            Privacy
          </Link>
          <Link href="#" className="text-gray-500 hover:text-gray-900 dark:hover:text-gray-300">
            Contact
          </Link>
        </div>
        <div className="text-sm text-gray-500">© 2025 Gym Management System. All rights reserved.</div>
      </div>
    </footer>
  )
}
