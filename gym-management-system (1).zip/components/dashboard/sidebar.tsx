"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Users,
  Receipt,
  Bell,
  ShoppingBag,
  Utensils,
  Home,
  Settings,
  Menu,
  X,
  LogOut,
  User,
  CreditCard,
  BarChart,
} from "lucide-react"
import { useAuth } from "@/components/auth-provider"

interface SidebarProps {
  userRole: string
}

export function DashboardSidebar({ userRole }: SidebarProps) {
  const [isOpen, setIsOpen] = useState(false)
  const pathname = usePathname()
  const { logout } = useAuth()

  // Define navigation items based on user role
  const getNavItems = () => {
    const commonItems = [
      {
        title: "Dashboard",
        href: "/dashboard",
        icon: Home,
      },
      {
        title: "Profile",
        href: "/dashboard/profile",
        icon: User,
      },
    ]

    const adminItems = [
      {
        title: "Members",
        href: "/dashboard/members",
        icon: Users,
      },
      {
        title: "Payments",
        href: "/dashboard/payments",
        icon: CreditCard,
      },
      {
        title: "Receipts",
        href: "/dashboard/receipts",
        icon: Receipt,
      },
      {
        title: "Notifications",
        href: "/dashboard/notifications",
        icon: Bell,
      },
      {
        title: "Supplements",
        href: "/dashboard/supplements",
        icon: ShoppingBag,
      },
      {
        title: "Diet Plans",
        href: "/dashboard/diet-plans",
        icon: Utensils,
      },
      {
        title: "Reports",
        href: "/dashboard/reports",
        icon: BarChart,
      },
      {
        title: "Settings",
        href: "/dashboard/settings",
        icon: Settings,
      },
    ]

    const memberItems = [
      {
        title: "Payments",
        href: "/dashboard/payments",
        icon: CreditCard,
      },
      {
        title: "Receipts",
        href: "/dashboard/receipts",
        icon: Receipt,
      },
      {
        title: "Notifications",
        href: "/dashboard/notifications",
        icon: Bell,
      },
      {
        title: "Diet Plan",
        href: "/dashboard/diet-plan",
        icon: Utensils,
      },
      {
        title: "Supplements",
        href: "/dashboard/supplements",
        icon: ShoppingBag,
      },
    ]

    if (userRole === "admin") {
      return [...commonItems, ...adminItems]
    } else if (userRole === "member") {
      return [...commonItems, ...memberItems]
    } else {
      // Default user role
      return commonItems
    }
  }

  const navItems = getNavItems()

  return (
    <>
      {/* Mobile menu button */}
      <Button
        variant="outline"
        size="icon"
        className="fixed top-4 left-4 z-50 md:hidden"
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        <span className="sr-only">Toggle Menu</span>
      </Button>

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-64 transform border-r bg-white transition-transform duration-200 ease-in-out dark:bg-gray-950 md:translate-x-0",
          isOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex h-16 items-center border-b px-6">
          <Link href="/dashboard" className="flex items-center gap-2 font-bold">
            <span className="text-primary">GYM</span> Management
          </Link>
        </div>
        <ScrollArea className="h-[calc(100vh-4rem)]">
          <div className="px-3 py-4">
            <nav className="flex flex-col gap-1">
              {navItems.map((item, index) => (
                <Link
                  key={index}
                  href={item.href}
                  onClick={() => setIsOpen(false)}
                  className={cn(
                    "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                    pathname === item.href
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-gray-100 dark:hover:bg-gray-800",
                  )}
                >
                  <item.icon className="h-5 w-5" />
                  {item.title}
                </Link>
              ))}
              <Button
                variant="ghost"
                className="flex w-full items-center justify-start gap-3 px-3 py-2 text-sm font-medium"
                onClick={logout}
              >
                <LogOut className="h-5 w-5" />
                Sign Out
              </Button>
            </nav>
          </div>
        </ScrollArea>
      </aside>

      {/* Overlay for mobile */}
      {isOpen && <div className="fixed inset-0 z-30 bg-black/50 md:hidden" onClick={() => setIsOpen(false)} />}
    </>
  )
}
