"use client"

import { useState } from "react"
import Link from "next/link"
import { Bell, Sun, Moon, UserIcon } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useTheme } from "next-themes"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth-provider"

// Mock notifications for demo
const mockNotifications = [
  {
    id: "notif_1",
    title: "Payment Due",
    message: "Your monthly payment of $75.00 is due on June 1, 2025.",
    createdAt: new Date("2025-05-15"),
    read: false,
  },
  {
    id: "notif_2",
    title: "New Class Available",
    message: "A new Yoga class has been added to the schedule.",
    createdAt: new Date("2025-05-13"),
    read: true,
  },
  {
    id: "notif_3",
    title: "Membership Renewal",
    message: "Your membership will renew automatically on June 30, 2025.",
    createdAt: new Date("2025-05-10"),
    read: true,
  },
]

export function DashboardHeader({ user }: { user: any }) {
  const { setTheme } = useTheme()
  const [notifications, setNotifications] = useState(mockNotifications)
  const [notificationsLoaded, setNotificationsLoaded] = useState(true)
  const { toast } = useToast()
  const { logout } = useAuth()

  const handleNotificationClick = (notificationId: string) => {
    setNotifications(
      notifications.map((notification) =>
        notification.id === notificationId ? { ...notification, read: true } : notification,
      ),
    )
  }

  const unreadCount = notifications.filter((n) => !n.read).length

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b bg-white px-4 dark:bg-gray-950 md:px-6">
      <div className="hidden md:block">
        <h1 className="text-lg font-semibold">{user.role === "admin" ? "Admin Dashboard" : "Member Dashboard"}</h1>
      </div>

      <div className="flex items-center gap-4">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              {unreadCount > 0 && (
                <Badge
                  className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center"
                  variant="destructive"
                >
                  {unreadCount}
                </Badge>
              )}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-80">
            <div className="p-2">
              <h3 className="font-semibold mb-2">Notifications</h3>
              <div className="space-y-2 max-h-[300px] overflow-y-auto">
                {!notificationsLoaded ? (
                  <div className="text-center py-4">Loading notifications...</div>
                ) : notifications.length === 0 ? (
                  <div className="text-center py-4 text-gray-500">No notifications</div>
                ) : (
                  notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-2 rounded-md text-sm ${notification.read ? "bg-gray-100 dark:bg-gray-800" : "bg-primary/10"}`}
                      onClick={() => handleNotificationClick(notification.id)}
                    >
                      <div className="font-medium">{notification.title}</div>
                      <div className="text-gray-500 dark:text-gray-400">{notification.message}</div>
                      <div className="text-xs text-gray-400 mt-1">{notification.createdAt.toLocaleString()}</div>
                    </div>
                  ))
                )}
              </div>
              <div className="mt-2 pt-2 border-t text-center">
                <Link href="/dashboard/notifications" className="text-sm text-primary hover:underline">
                  View all notifications
                </Link>
              </div>
            </div>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="icon">
              <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              <span className="sr-only">Toggle theme</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => setTheme("light")}>Light</DropdownMenuItem>
            <DropdownMenuItem onClick={() => setTheme("dark")}>Dark</DropdownMenuItem>
            <DropdownMenuItem onClick={() => setTheme("system")}>System</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative h-8 w-8 rounded-full">
              <Avatar className="h-8 w-8">
                <AvatarImage src="/placeholder.svg" alt={user.displayName || "User"} />
                <AvatarFallback>
                  {user.displayName ? user.displayName.charAt(0).toUpperCase() : <UserIcon className="h-4 w-4" />}
                </AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56" align="end" forceMount>
            <div className="flex flex-col space-y-1 p-2">
              <p className="text-sm font-medium leading-none">{user.displayName || "User"}</p>
              <p className="text-xs leading-none text-gray-500 dark:text-gray-400">{user.email}</p>
            </div>
            <DropdownMenuItem asChild>
              <Link href="/dashboard/profile">Profile</Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href="/dashboard/settings">Settings</Link>
            </DropdownMenuItem>
            <DropdownMenuItem className="text-red-500 dark:text-red-400" onClick={logout}>
              Sign out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
