import { Users, Receipt, Bell, ShoppingBag, Utensils, FileText, Calendar, CreditCard } from "lucide-react"

export function Features() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50 dark:bg-gray-900" id="features">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <div className="inline-block rounded-lg bg-primary px-3 py-1 text-sm text-primary-foreground">Features</div>
            <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Everything You Need</h2>
            <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
              Our gym management system provides a complete solution for gym owners and members.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-12">
          <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm bg-white dark:bg-gray-950">
            <div className="rounded-full bg-primary/10 p-3">
              <Users className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Member Management</h3>
            <p className="text-center text-gray-500 dark:text-gray-400">
              Add, update, and manage gym members with ease.
            </p>
          </div>
          <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm bg-white dark:bg-gray-950">
            <div className="rounded-full bg-primary/10 p-3">
              <Receipt className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Digital Receipts</h3>
            <p className="text-center text-gray-500 dark:text-gray-400">
              Generate and store digital receipts for all payments.
            </p>
          </div>
          <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm bg-white dark:bg-gray-950">
            <div className="rounded-full bg-primary/10 p-3">
              <Bell className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Automated Notifications</h3>
            <p className="text-center text-gray-500 dark:text-gray-400">
              Send payment reminders and gym announcements automatically.
            </p>
          </div>
          <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm bg-white dark:bg-gray-950">
            <div className="rounded-full bg-primary/10 p-3">
              <ShoppingBag className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Supplement Store</h3>
            <p className="text-center text-gray-500 dark:text-gray-400">
              Manage and sell supplements directly through the platform.
            </p>
          </div>
          <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm bg-white dark:bg-gray-950">
            <div className="rounded-full bg-primary/10 p-3">
              <Utensils className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Diet Plans</h3>
            <p className="text-center text-gray-500 dark:text-gray-400">
              Create and assign personalized diet plans to members.
            </p>
          </div>
          <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm bg-white dark:bg-gray-950">
            <div className="rounded-full bg-primary/10 p-3">
              <FileText className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Reports & Analytics</h3>
            <p className="text-center text-gray-500 dark:text-gray-400">
              Generate comprehensive reports on gym performance.
            </p>
          </div>
          <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm bg-white dark:bg-gray-950">
            <div className="rounded-full bg-primary/10 p-3">
              <Calendar className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Class Scheduling</h3>
            <p className="text-center text-gray-500 dark:text-gray-400">
              Manage and schedule fitness classes and trainings.
            </p>
          </div>
          <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm bg-white dark:bg-gray-950">
            <div className="rounded-full bg-primary/10 p-3">
              <CreditCard className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Payment Processing</h3>
            <p className="text-center text-gray-500 dark:text-gray-400">
              Handle membership fees and other payments securely.
            </p>
          </div>
          <div className="md:col-span-2 lg:col-span-1 flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm bg-white dark:bg-gray-950">
            <div className="rounded-full bg-primary/10 p-3">
              <Users className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Attendance Tracking</h3>
            <p className="text-center text-gray-500 dark:text-gray-400">
              Monitor member attendance and gym usage patterns.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
