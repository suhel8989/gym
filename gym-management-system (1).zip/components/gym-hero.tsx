import Link from "next/link"
import { Button } from "@/components/ui/button"

export function GymHero() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 relative">
      {/* Background image with overlay */}
      <div
        className="absolute inset-0 bg-cover bg-center z-0"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80')",
          backgroundPosition: "center 30%",
        }}
      >
        <div className="absolute inset-0 bg-black/60"></div>
      </div>

      <div className="container px-4 md:px-6 relative z-10">
        <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
          <div className="space-y-4">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-white">
              Digital Gym Management Solution
            </h1>
            <p className="max-w-[600px] text-gray-200 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Streamline your gym operations with our comprehensive management system. Digital receipts, automated
              notifications, and member management all in one place.
            </p>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/login">
                <Button className="bg-primary hover:bg-primary/90">Get Started</Button>
              </Link>
              <Link href="#features">
                <Button variant="outline" className="border-white text-white hover:bg-white/10">
                  Learn More
                </Button>
              </Link>
            </div>
          </div>
          <div className="flex justify-center">
            <div className="bg-white p-2 rounded-lg shadow-xl rotate-3 transform hover:rotate-0 transition-transform duration-300">
              <img
                src="https://images.unsplash.com/photo-1576678927484-cc907957088c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80"
                alt="Gym Management Dashboard"
                className="rounded-lg object-cover h-[400px] w-[600px]"
                width={600}
                height={400}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
