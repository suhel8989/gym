export function Testimonials() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32" id="testimonials">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <div className="inline-block rounded-lg bg-primary px-3 py-1 text-sm text-primary-foreground">
              Testimonials
            </div>
            <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">What Our Clients Say</h2>
            <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
              Hear from gym owners who have transformed their business with our management system.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-12">
          <div className="flex flex-col space-y-4 rounded-lg border p-6 shadow-sm bg-white dark:bg-gray-950">
            <div className="flex items-center space-x-4">
              <img
                src="https://images.unsplash.com/photo-1534368786749-b63e05c92717?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
                alt="John Smith"
                className="h-12 w-12 rounded-full object-cover"
              />
              <div>
                <h3 className="font-bold">John Smith</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Fitness First Gym</p>
              </div>
            </div>
            <p className="text-gray-500 dark:text-gray-400">
              "This system has completely transformed how we manage our gym. Digital receipts have eliminated paperwork,
              and the automated notifications have reduced our no-shows by 35%."
            </p>
          </div>
          <div className="flex flex-col space-y-4 rounded-lg border p-6 shadow-sm bg-white dark:bg-gray-950">
            <div className="flex items-center space-x-4">
              <img
                src="https://images.unsplash.com/photo-1548690312-e3b507d8c110?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80"
                alt="Sarah Johnson"
                className="h-12 w-12 rounded-full object-cover"
              />
              <div>
                <h3 className="font-bold">Sarah Johnson</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Elite Fitness Center</p>
              </div>
            </div>
            <p className="text-gray-500 dark:text-gray-400">
              "The member management features are incredible. We've been able to grow our membership by 25% while
              reducing administrative work. The reporting tools give us insights we never had before."
            </p>
          </div>
          <div className="flex flex-col space-y-4 rounded-lg border p-6 shadow-sm bg-white dark:bg-gray-950">
            <div className="flex items-center space-x-4">
              <img
                src="https://images.unsplash.com/photo-1517838277536-f5f99be501cd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
                alt="Michael Rodriguez"
                className="h-12 w-12 rounded-full object-cover"
              />
              <div>
                <h3 className="font-bold">Michael Rodriguez</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">PowerHouse Gym</p>
              </div>
            </div>
            <p className="text-gray-500 dark:text-gray-400">
              "The supplement store integration has added a new revenue stream for our gym. Members love the diet plans
              feature, and it's helped us retain clients longer. Highly recommended!"
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
