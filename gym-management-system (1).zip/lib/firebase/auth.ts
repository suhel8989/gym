import {
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  createUserWithEmailAndPassword,
  updateProfile,
  sendPasswordResetEmail,
} from "firebase/auth"
import { auth } from "./config"
import { logEvent } from "./analytics"

// Check if auth is available and has methods
const isAuthAvailable = auth && typeof auth.signInWithEmailAndPassword === "function"

// Sign in with email and password
export async function signIn(email: string, password: string) {
  try {
    if (!isAuthAvailable) {
      // Demo mode - return mock user based on email
      if (email === "admin@example.com" && password === "password") {
        const mockUser = {
          uid: "admin-user-id",
          email: "admin@example.com",
          displayName: "Admin User",
          emailVerified: true,
        }
        logEvent("login", { method: "email", role: "admin" })
        return { user: mockUser, error: null }
      } else if (email === "member@example.com" && password === "password") {
        const mockUser = {
          uid: "member-user-id",
          email: "member@example.com",
          displayName: "Member User",
          emailVerified: true,
        }
        logEvent("login", { method: "email", role: "member" })
        return { user: mockUser, error: null }
      } else {
        return {
          user: null,
          error: new Error(
            "Invalid email or password. Try admin@example.com / password or member@example.com / password",
          ),
        }
      }
    }

    const userCredential = await signInWithEmailAndPassword(auth, email, password)
    logEvent("login", { method: "email" })
    return { user: userCredential.user, error: null }
  } catch (error) {
    console.error("Sign in error:", error)
    return { user: null, error: error as Error }
  }
}

// Sign out
export async function signOut() {
  try {
    if (!isAuthAvailable) {
      // Demo mode
      logEvent("logout")
      return { success: true, error: null }
    }

    await firebaseSignOut(auth)
    logEvent("logout")
    return { success: true, error: null }
  } catch (error) {
    console.error("Sign out error:", error)
    return { success: false, error: error as Error }
  }
}

// Create a new user (admin only function)
export async function createUser(email: string, password: string, displayName: string) {
  try {
    if (!isAuthAvailable) {
      // Demo mode
      const mockUser = {
        uid: `user-${Date.now()}`,
        email,
        displayName,
        emailVerified: false,
      }
      logEvent("user_created", { method: "email" })
      return { user: mockUser, error: null }
    }

    const userCredential = await createUserWithEmailAndPassword(auth, email, password)

    // Update profile with display name
    await updateProfile(userCredential.user, { displayName })

    logEvent("user_created", { method: "email" })
    return { user: userCredential.user, error: null }
  } catch (error) {
    console.error("Create user error:", error)
    return { user: null, error: error as Error }
  }
}

// Send password reset email
export async function resetPassword(email: string) {
  try {
    if (!isAuthAvailable) {
      // Demo mode
      logEvent("password_reset_email_sent")
      return { success: true, error: null }
    }

    await sendPasswordResetEmail(auth, email)
    logEvent("password_reset_email_sent")
    return { success: true, error: null }
  } catch (error) {
    console.error("Password reset error:", error)
    return { success: false, error: error as Error }
  }
}
