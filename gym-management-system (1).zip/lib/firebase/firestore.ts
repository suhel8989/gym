import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  addDoc,
  serverTimestamp,
} from "firebase/firestore"
import { db } from "./config"
import { logEvent } from "./analytics"

// Check if Firestore is available
const isFirestoreAvailable = db && typeof db.collection === "function"

// Mock notifications for demo mode
const mockNotifications = [
  {
    id: "notif_1",
    userId: "admin-user-id",
    title: "New Member Registration",
    message: "John Doe has registered as a new member.",
    createdAt: { toDate: () => new Date("2025-05-15") },
    read: false,
  },
  {
    id: "notif_2",
    userId: "admin-user-id",
    title: "Payment Received",
    message: "Payment of $75.00 received from Jane Smith.",
    createdAt: { toDate: () => new Date("2025-05-14") },
    read: true,
  },
  {
    id: "notif_3",
    userId: "member-user-id",
    title: "Payment Due",
    message: "Your monthly payment of $75.00 is due on June 1, 2025.",
    createdAt: { toDate: () => new Date("2025-05-15") },
    read: false,
  },
  {
    id: "notif_4",
    userId: "member-user-id",
    title: "New Class Available",
    message: "A new Yoga class has been added to the schedule.",
    createdAt: { toDate: () => new Date("2025-05-13") },
    read: true,
  },
  {
    id: "notif_5",
    userId: "member-user-id",
    title: "Membership Renewal",
    message: "Your membership will renew automatically on June 30, 2025.",
    createdAt: { toDate: () => new Date("2025-05-10") },
    read: true,
  },
]

// Get user role
export async function getUserRole(userId: string) {
  try {
    // Demo mode roles
    if (userId === "admin-user-id") return "admin"
    if (userId === "member-user-id") return "member"

    // If Firestore is not available, return a demo role
    if (!isFirestoreAvailable) {
      return userId.includes("admin") ? "admin" : "member"
    }

    const userDoc = await getDoc(doc(db, "users", userId))
    if (userDoc.exists()) {
      return userDoc.data().role
    }
    return null
  } catch (error) {
    console.error("Error getting user role:", error)
    return userId.includes("admin") ? "admin" : "member" // Fallback
  }
}

// Create a new user in Firestore
export async function createUserInFirestore(userId: string, userData: any) {
  try {
    if (!isFirestoreAvailable) {
      // Demo mode
      logEvent("user_created_in_firestore", { userId })
      return { success: true, error: null }
    }

    await setDoc(doc(db, "users", userId), {
      ...userData,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })
    logEvent("user_created_in_firestore", { userId })
    return { success: true, error: null }
  } catch (error) {
    console.error("Error creating user in Firestore:", error)
    logEvent("error_creating_user", { error: (error as Error).message })
    return { success: false, error: error as Error }
  }
}

// Get all members
export async function getMembers() {
  try {
    if (!isFirestoreAvailable) {
      // Return mock data for demo mode
      return {
        members: [
          {
            id: "mem_1",
            name: "John Doe",
            email: "john@example.com",
            phone: "+1 (555) 123-4567",
            status: "active",
            membershipType: "Premium",
            createdAt: new Date("2025-01-15"),
          },
          {
            id: "mem_2",
            name: "Jane Smith",
            email: "jane@example.com",
            phone: "+1 (555) 987-6543",
            status: "active",
            membershipType: "Standard",
            createdAt: new Date("2025-02-20"),
          },
          {
            id: "mem_3",
            name: "Robert Johnson",
            email: "robert@example.com",
            phone: "+1 (555) 456-7890",
            status: "inactive",
            membershipType: "Basic",
            createdAt: new Date("2025-03-10"),
          },
          {
            id: "mem_4",
            name: "Emily Davis",
            email: "emily@example.com",
            phone: "+1 (555) 234-5678",
            status: "active",
            membershipType: "VIP",
            createdAt: new Date("2025-04-05"),
          },
          {
            id: "mem_5",
            name: "Michael Wilson",
            email: "michael@example.com",
            phone: "+1 (555) 876-5432",
            status: "pending",
            membershipType: "Premium",
            createdAt: new Date("2025-05-01"),
          },
        ],
        error: null,
      }
    }

    const q = query(collection(db, "users"), where("role", "==", "member"), orderBy("createdAt", "desc"))

    const querySnapshot = await getDocs(q)
    const members = querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    return { members, error: null }
  } catch (error) {
    console.error("Error getting members:", error)
    return { members: [], error: error as Error }
  }
}

// Get member by ID
export async function getMemberById(memberId: string) {
  try {
    if (!isFirestoreAvailable) {
      // Return mock data for demo mode
      const mockMember = {
        id: memberId,
        name: "John Doe",
        email: "john@example.com",
        phone: "+1 (555) 123-4567",
        address: "123 Main St, Anytown, USA",
        emergencyContact: "Jane Doe: +1 (555) 987-6543",
        dateOfBirth: "1990-01-15",
        gender: "male",
        membershipType: "Premium",
        status: "active",
        createdAt: new Date("2025-01-15"),
      }
      return { member: mockMember, error: null }
    }

    const memberDoc = await getDoc(doc(db, "users", memberId))

    if (memberDoc.exists()) {
      return {
        member: { id: memberDoc.id, ...memberDoc.data() },
        error: null,
      }
    } else {
      return { member: null, error: new Error("Member not found") }
    }
  } catch (error) {
    console.error("Error getting member:", error)
    return { member: null, error: error as Error }
  }
}

// Create a new member
export async function createMember(memberData: any) {
  try {
    if (!isFirestoreAvailable) {
      // Demo mode
      const mockId = `mem_${Date.now()}`
      logEvent("member_created", { memberId: mockId })
      return { memberId: mockId, error: null }
    }

    // Create a new document with auto-generated ID
    const docRef = await addDoc(collection(db, "users"), {
      ...memberData,
      role: "member",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })

    logEvent("member_created", { memberId: docRef.id })
    return { memberId: docRef.id, error: null }
  } catch (error) {
    console.error("Error creating member:", error)
    return { memberId: null, error: error as Error }
  }
}

// Update a member
export async function updateMember(memberId: string, memberData: any) {
  try {
    if (!isFirestoreAvailable) {
      // Demo mode
      logEvent("member_updated", { memberId })
      return { success: true, error: null }
    }

    await updateDoc(doc(db, "users", memberId), {
      ...memberData,
      updatedAt: serverTimestamp(),
    })

    logEvent("member_updated", { memberId })
    return { success: true, error: null }
  } catch (error) {
    console.error("Error updating member:", error)
    return { success: false, error: error as Error }
  }
}

// Delete a member
export async function deleteMember(memberId: string) {
  try {
    if (!isFirestoreAvailable) {
      // Demo mode
      logEvent("member_deleted", { memberId })
      return { success: true, error: null }
    }

    await deleteDoc(doc(db, "users", memberId))

    logEvent("member_deleted", { memberId })
    return { success: true, error: null }
  } catch (error) {
    console.error("Error deleting member:", error)
    return { success: false, error: error as Error }
  }
}

// Create a new payment
export async function createPayment(paymentData: any) {
  try {
    if (!isFirestoreAvailable) {
      // Demo mode
      const mockId = `pay_${Date.now()}`
      logEvent("payment_created", { paymentId: mockId })
      return { paymentId: mockId, error: null }
    }

    const docRef = await addDoc(collection(db, "payments"), {
      ...paymentData,
      createdAt: serverTimestamp(),
      status: "paid",
    })

    logEvent("payment_created", { paymentId: docRef.id })
    return { paymentId: docRef.id, error: null }
  } catch (error) {
    console.error("Error creating payment:", error)
    return { paymentId: null, error: error as Error }
  }
}

// Get payments for a member
export async function getMemberPayments(memberId: string) {
  try {
    if (!isFirestoreAvailable) {
      // Return mock data for demo mode
      return {
        payments: [
          {
            id: "pay_1",
            memberId: memberId,
            amount: 75.0,
            date: "2025-05-01",
            status: "paid",
            paymentMethod: "credit_card",
            description: "Monthly membership fee - May 2025",
          },
          {
            id: "pay_2",
            memberId: memberId,
            amount: 75.0,
            date: "2025-04-01",
            status: "paid",
            paymentMethod: "credit_card",
            description: "Monthly membership fee - April 2025",
          },
          {
            id: "pay_3",
            memberId: memberId,
            amount: 75.0,
            date: "2025-03-01",
            status: "paid",
            paymentMethod: "bank_transfer",
            description: "Monthly membership fee - March 2025",
          },
        ],
        error: null,
      }
    }

    const q = query(collection(db, "payments"), where("memberId", "==", memberId), orderBy("createdAt", "desc"))

    const querySnapshot = await getDocs(q)
    const payments = querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    return { payments, error: null }
  } catch (error) {
    console.error("Error getting member payments:", error)
    return { payments: [], error: error as Error }
  }
}

// Create a notification
export async function createNotification(notificationData: any) {
  try {
    if (!isFirestoreAvailable) {
      // Demo mode
      const mockId = `notif_${Date.now()}`
      logEvent("notification_created", { notificationId: mockId })
      return { notificationId: mockId, error: null }
    }

    const docRef = await addDoc(collection(db, "notifications"), {
      ...notificationData,
      createdAt: serverTimestamp(),
      read: false,
    })

    logEvent("notification_created", { notificationId: docRef.id })
    return { notificationId: docRef.id, error: null }
  } catch (error) {
    console.error("Error creating notification:", error)
    return { notificationId: null, error: error as Error }
  }
}

// Get notifications for a user
export async function getUserNotifications(userId: string) {
  try {
    if (!isFirestoreAvailable) {
      // Return mock notifications for demo mode
      const userNotifications = mockNotifications.filter((n) => n.userId === userId)
      return { notifications: userNotifications, error: null }
    }

    const q = query(
      collection(db, "notifications"),
      where("userId", "==", userId),
      orderBy("createdAt", "desc"),
      limit(20),
    )

    const querySnapshot = await getDocs(q)
    const notifications = querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    return { notifications, error: null }
  } catch (error) {
    console.error("Error getting user notifications:", error)
    // Return mock notifications as fallback
    const userNotifications = mockNotifications.filter((n) => n.userId === userId)
    return { notifications: userNotifications, error: null }
  }
}

// Mark notification as read
export async function markNotificationAsRead(notificationId: string) {
  try {
    if (!isFirestoreAvailable) {
      // Demo mode
      return { success: true, error: null }
    }

    await updateDoc(doc(db, "notifications", notificationId), {
      read: true,
      readAt: serverTimestamp(),
    })

    return { success: true, error: null }
  } catch (error) {
    console.error("Error marking notification as read:", error)
    return { success: false, error: error as Error }
  }
}

// Get all packages
export async function getPackages() {
  try {
    if (!isFirestoreAvailable) {
      // Return mock data for demo mode
      return {
        packages: [
          {
            id: "pkg_1",
            name: "Basic",
            price: 50,
            description: "Access to gym facilities during regular hours",
            features: ["Gym access", "Locker room access"],
            duration: 30, // days
          },
          {
            id: "pkg_2",
            name: "Standard",
            price: 75,
            description: "Access to gym facilities and group classes",
            features: ["Gym access", "Locker room access", "Group classes"],
            duration: 30, // days
          },
          {
            id: "pkg_3",
            name: "Premium",
            price: 100,
            description: "Full access to all gym facilities and services",
            features: ["Gym access", "Locker room access", "Group classes", "Personal training session (1/month)"],
            duration: 30, // days
          },
          {
            id: "pkg_4",
            name: "VIP",
            price: 150,
            description: "Exclusive access and personalized services",
            features: [
              "24/7 Gym access",
              "Locker room access",
              "Unlimited group classes",
              "Personal training sessions (2/month)",
              "Nutrition consultation",
            ],
            duration: 30, // days
          },
        ],
        error: null,
      }
    }

    const querySnapshot = await getDocs(collection(db, "packages"))
    const packages = querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    return { packages, error: null }
  } catch (error) {
    console.error("Error getting packages:", error)
    return { packages: [], error: error as Error }
  }
}

// Create a package
export async function createPackage(packageData: any) {
  try {
    if (!isFirestoreAvailable) {
      // Demo mode
      const mockId = `pkg_${Date.now()}`
      logEvent("package_created", { packageId: mockId })
      return { packageId: mockId, error: null }
    }

    const docRef = await addDoc(collection(db, "packages"), {
      ...packageData,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    })

    logEvent("package_created", { packageId: docRef.id })
    return { packageId: docRef.id, error: null }
  } catch (error) {
    console.error("Error creating package:", error)
    return { packageId: null, error: error as Error }
  }
}
