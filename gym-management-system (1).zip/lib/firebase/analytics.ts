import { logEvent as firebaseLogEvent } from "firebase/analytics"
import { analytics } from "./config"

// Log an event to Firebase Analytics
export function logEvent(eventName: string, eventParams?: Record<string, any>) {
  try {
    if (analytics && typeof analytics.logEvent === "function" && typeof window !== "undefined") {
      firebaseLogEvent(analytics, eventName, eventParams)
    } else {
      // For server-side or when analytics is not available
      console.log(`[Analytics Event] ${eventName}`, eventParams)
    }
  } catch (error) {
    console.error("Error logging event:", error)
  }
}
